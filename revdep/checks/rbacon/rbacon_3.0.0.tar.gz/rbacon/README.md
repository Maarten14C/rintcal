# rbacon

Software for Bayesian age-depth modelling.

For tutorials, check out the vignettes at the [CRAN](https://cran.r-project.org/package=rbacon) version.
