# coffee 0.2.0
* now links to the rintcal package (renamed from IntCal)
* the strat function now handles undated levels, blocks of dates, and different types of gaps (of exactly known length, or according to a normal or gamma distribution)

# coffee 0.1.1

* added references to the methods to the DESCRIPTION file
* replaced all instances of cat() with message()
* the original par settings are now saved if the function is exited

# coffee  0.1.0

* this is the first CRAN iteration of the coffee package

