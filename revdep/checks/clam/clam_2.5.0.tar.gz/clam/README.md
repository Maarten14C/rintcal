# clam
A package for 'classical' age-depth modelling of cores from deposits. 

Please see the Vignette for a tutorial.
